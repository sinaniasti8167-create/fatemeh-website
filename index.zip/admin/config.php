<?php
declare(strict_types=1);
const DB_HOST='test-kou-service';
const DB_PORT=3306;
const DB_NAME='testlwb_db';
const DB_USER='root';
const DB_PASS='Sina-Fateme';

function db(): PDO {
 static $pdo=null;
 if ($pdo instanceof PDO) return $pdo;
 $pdo=new PDO('mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
  PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES=>false
 ]);
 return $pdo;
}
function start_admin_session(): void {
 if(session_status()===PHP_SESSION_ACTIVE) return;
 $secure=!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off';
 session_set_cookie_params(['lifetime'=>0,'path'=>'/admin/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
 session_start();
}
function csrf_token(): string {
 start_admin_session();
 if(empty($_SESSION['csrf_token'])) $_SESSION['csrf_token']=bin2hex(random_bytes(32));
 return $_SESSION['csrf_token'];
}
function verify_csrf(): void {
 start_admin_session();
 $sent=$_POST['csrf_token']??'';
 if(!is_string($sent)||!hash_equals($_SESSION['csrf_token']??'', $sent)){http_response_code(400);exit('درخواست نامعتبر است.');}
}
function require_admin(): void {
 start_admin_session();
 if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}
}
