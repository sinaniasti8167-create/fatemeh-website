<?php
require __DIR__.'/config.php'; start_admin_session();
try{$count=(int)db()->query('SELECT COUNT(*) FROM admin_users')->fetchColumn();}
catch(Throwable $e){http_response_code(500);exit('اتصال دیتابیس برقرار نشد؛ تنظیمات config.php را بررسی کنید.');}
if($count>0){http_response_code(403);exit('مدیر قبلاً ساخته شده است. این فایل را حذف کنید.');}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $name=trim($_POST['full_name']??''); $user=trim($_POST['username']??''); $pass=$_POST['password']??'';
 if($name===''||!preg_match('/^[a-zA-Z0-9_.-]{3,80}$/',$user)||strlen($pass)<12)$error='نام را وارد کنید؛ نام کاربری انگلیسی حداقل ۳ و رمز حداقل ۱۲ نویسه باشد.';
 else{
  try{$s=db()->prepare('INSERT INTO admin_users(full_name,username,password_hash,role,is_active) VALUES(?,?,?,"owner",1)');$s->execute([$name,$user,password_hash($pass,PASSWORD_DEFAULT)]);header('Location: login.php?created=1');exit;}
  catch(PDOException $e){$error='ساخت حساب انجام نشد؛ ممکن است نام کاربری تکراری باشد.';}
 }
}
?><!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ساخت مدیر</title>
<style>body{font-family:Tahoma;background:#f4f6fb;padding:30px;color:#202638}.card{max-width:430px;margin:7vh auto;background:white;padding:26px;border-radius:15px}label{display:block;margin:14px 0 6px}input{box-sizing:border-box;width:100%;padding:12px;border:1px solid #ccd3df;border-radius:8px}button{margin-top:18px;width:100%;padding:12px;background:#2457a7;color:white;border:0;border-radius:8px}.err{color:#b42318}</style>
<div class="card"><h2>ساخت حساب مدیر</h2><p>این فرم فقط برای اولین مدیر است.</p><?php if($error):?><p class="err"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></p><?php endif;?>
<form method="post"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><label>نام و نام خانوادگی</label><input name="full_name" required><label>نام کاربری انگلیسی</label><input name="username" required minlength="3"><label>رمز عبور (حداقل ۱۲ نویسه)</label><input type="password" name="password" required minlength="12"><button>ساخت حساب مدیر</button></form></div></html>
