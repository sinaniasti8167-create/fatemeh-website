<?php
require __DIR__.'/config.php';require_admin();
$counts=[
'درخواست‌های ثبت‌نام'=>(int)db()->query("SELECT COUNT(*) FROM registration_requests WHERE status='new'")->fetchColumn(),
'رزروهای در انتظار'=>(int)db()->query("SELECT COUNT(*) FROM bookings WHERE status='requested'")->fetchColumn(),
'نظرات در انتظار'=>(int)db()->query("SELECT COUNT(*) FROM reviews WHERE status='pending'")->fetchColumn(),
'زبان‌آموزان'=>(int)db()->query("SELECT COUNT(*) FROM students")->fetchColumn()
];
?><!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>داشبورد</title><style>body{font-family:Tahoma;background:#f4f6fb;padding:28px;color:#202638}.wrap{max-width:900px;margin:auto}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:15px}.item{background:white;padding:22px;border-radius:14px}.num{font-size:30px;color:#2457a7;font-weight:bold}a{color:#2457a7}</style><div class="wrap"><p>خوش آمدید، <?=htmlspecialchars($_SESSION['admin_name'],ENT_QUOTES,'UTF-8')?> | <a href="logout.php">خروج</a></p><h1>پنل مدیریت Deutsch-Barati</h1><div class="grid"><?php foreach($counts as $label=>$value):?><div class="item"><?=htmlspecialchars($label,ENT_QUOTES,'UTF-8')?><p class="num"><?=$value?></p></div><?php endforeach;?></div><p>این داشبورد نسخه اولیه است؛ مدیریت جزئی درخواست‌ها، رزروها و نظرات در مرحله بعد اضافه می‌شود.</p></div></html>
