<?php
require __DIR__.'/config.php'; start_admin_session();
if(!empty($_SESSION['admin_id'])){header('Location: index.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();$user=trim($_POST['username']??'');$pass=$_POST['password']??'';
 $s=db()->prepare('SELECT id,full_name,password_hash FROM admin_users WHERE username=? AND is_active=1 LIMIT 1');$s->execute([$user]);$a=$s->fetch();
 if($a&&password_verify($pass,$a['password_hash'])){session_regenerate_id(true);$_SESSION['admin_id']=(int)$a['id'];$_SESSION['admin_name']=$a['full_name'];db()->prepare('UPDATE admin_users SET last_login_at=NOW() WHERE id=?')->execute([$a['id']]);header('Location: index.php');exit;}
 $error='نام کاربری یا رمز عبور صحیح نیست.';
}
?><!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ورود مدیریت</title><style>body{font-family:Tahoma;background:#f4f6fb;padding:30px;color:#202638}.card{max-width:420px;margin:8vh auto;background:white;padding:26px;border-radius:15px}label{display:block;margin:14px 0 6px}input{box-sizing:border-box;width:100%;padding:12px;border:1px solid #ccd3df;border-radius:8px}button{margin-top:18px;width:100%;padding:12px;background:#2457a7;color:white;border:0;border-radius:8px}.err{color:#b42318}</style><div class="card"><h2>پنل مدیریت فاطمه</h2><p>ورود مدیر Deutsch-Barati</p><?php if($error):?><p class="err"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></p><?php endif;?><form method="post"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><label>نام کاربری</label><input name="username" required><label>رمز عبور</label><input type="password" name="password" required><button>ورود</button></form></div></html>
